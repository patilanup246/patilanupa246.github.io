# -*- coding: utf-8 -*-
import scrapy
import csv
import os
from scrapy.crawler import CrawlerProcess
import openpyxl




class AlibabaCrawlerSpider(scrapy.Spider):
    name = 'alibaba_crawler'
    allowed_domains = ['alibaba.com']
    start_urls = ['http://alibaba.com/']

    try:
        wb = openpyxl.load_workbook('alibaba.xlsx')
        ws = wb.get_active_sheet()
        row_count = ws.max_row
        i = row_count + 1
        # print(headings)
    except:
        wb = openpyxl.Workbook()
        ws = wb.get_active_sheet()
        # print(ws)

        ws.cell(row=1, column=1).value = "#"
        ws.cell(row=1, column=2).value = "search_text"
        ws.cell(row=1, column=3).value = "product_link"
        ws.cell(row=1, column=4).value = "product_name"
        ws.cell(row=1, column=5).value = "product_image"
        ws.cell(row=1, column=6).value = "product_price"
        ws.cell(row=1, column=7).value = "company_name"
        ws.cell(row=1, column=8).value = "product_rating"
        ws.cell(row=1, column=9).value = "product_reviews"
        ws.cell(row=1, column=10).value = "seller_name"
        i = 2




    def start_requests(self):
        """Read keywords from keywords file amd construct the search URL"""

        with open(os.path.join(os.path.dirname(__file__), "keywords.csv")) as search_keywords:
            for keyword in csv.DictReader(search_keywords):
                search_text=keyword["keyword"]
                #search_text='Toothbrushes'
                url="https://www.alibaba.com/trade/search?fsb=y&IndexArea=product_en&CatId=&SearchText={0}&viewtype=G".format(
                    search_text)
                # The meta is used to send our search text into the parser as metadata
                yield scrapy.Request(url, callback = self.parse, meta = {"search_text": search_text,"page":2},dont_filter=True)


    def parse(self, response):
        """Function to process alibaba search results page"""
        #print(response)
        strhtml = response.body
        strhtml = strhtml.decode('utf-8')
        search_keyword=response.meta["search_text"]
        page=response.meta["page"]
        products=response.xpath("//div[@class='item-main']")
        # iterating over search results
        for product in products:
            # Defining the XPaths
            XPATH_PRODUCT_NAME=".//div[@class='item-info']//h2[contains(@class,'title')]//a/@title"
            XPATH_PRODUCT_PRICE=".//div[@class='item-info']//div[@class='price']/b/text()"
            XPATH_PRODUCT_MIN_ORDER=".//div[@class='item-info']//div[@class='min-order']/b/text()"
            XPATH_SELLER_YEARS=".//div[@class='item-info']//div[@class='stitle util-ellipsis']//div[contains(@class,'supplier-year')]//text()"
            XPATH_SELLER_NAME=".//div[@class='item-info']//div[@class='stitle util-ellipsis']//a/@title"
            XPATH_SELLER_RESPONSE_RATE=".//div[@class='item-info']//div[@class='sstitle']//div[@class='num']/i/text()"
            XPATH_TRANSACTION_LEVEL=".//div[@class='item-info']//div[@class='sstitle']//a[@class='diamond-level-group']//i[contains(@class,'diamond-level-one')]"
            XPATH_TRANSACTION_LEVEL_FRACTION=".//div[@class='item-info']//div[@class='sstitle']//a[@class='diamond-level-group']//i[contains(@class,'diamond-level-half-filled')]"
            XPATH_PRODUCT_LINK=".//div[@class='item-info']//h2/a/@href"
            XPATH_PRODUCT_IMAGE=".//img[@data-buyer-portrait-info='image.mainImage']/@src"

            raw_product_name=product.xpath(XPATH_PRODUCT_NAME).extract()
            raw_product_price=product.xpath(XPATH_PRODUCT_PRICE).extract()
            raw_minimum_order=product.xpath(XPATH_PRODUCT_MIN_ORDER).extract()
            raw_seller_years=product.xpath(XPATH_SELLER_YEARS).extract()
            raw_seller_name=product.xpath(XPATH_SELLER_NAME).extract()
            raw_seller_response_rate=product.xpath(
                XPATH_SELLER_RESPONSE_RATE).extract()
            raw_transaction_level=product.xpath(
                XPATH_TRANSACTION_LEVEL).extract()
            raw_product_link=product.xpath(XPATH_PRODUCT_LINK).extract()
            raw_product_image=product.xpath(XPATH_PRODUCT_IMAGE).extract()
            # getting the fraction part
            raw_transaction_level_fraction=product.xpath(
                XPATH_TRANSACTION_LEVEL_FRACTION)

            # cleaning the data
            product_name=''.join(raw_product_name).strip(
            ) if raw_product_name else None
            product_price=''.join(raw_product_price).strip(
            ) if raw_product_price else None
            minimum_order=''.join(raw_minimum_order).strip(
            ) if raw_minimum_order else None
            seller_years_on_alibaba=''.join(
                raw_seller_years).strip() if raw_seller_years else None
            seller_name=''.join(raw_seller_name).strip(
            ) if raw_seller_name else None
            seller_response_rate=''.join(raw_seller_response_rate).strip(
            ) if raw_seller_response_rate else None
            # getting actual transaction levels by adding the fraction part
            transaction_level=len(raw_transaction_level)+.5 if raw_transaction_level_fraction else len(raw_transaction_level)
            product_link="https:" + raw_product_link[0] if raw_product_link else None
            product_image="https:" + raw_product_image[0] if raw_product_image else None

            yield scrapy.Request(product_link, callback=self.get_data,
                                 meta={"search_text": search_keyword,"page":page+1,
                                       "product_price":product_price,"minimum_order":minimum_order,
                                       "seller_name":seller_name},dont_filter=True)


        if products != []:
            nextpage = "https://www.alibaba.com/products/"+str(search_keyword)+".html?IndexArea=product_en&page="+str(page)+"&viewtype=G"
            yield scrapy.Request(nextpage, callback=self.parse, meta={"search_text": search_keyword,"page":page+1},dont_filter=True)

    def get_data(self, response):
        print(response)
        strhtml = response.body
        strhtml = strhtml.decode('utf-8')




        search_keyword=response.meta["search_text"]
        product_price=response.meta["product_price"]
        minimum_order=response.meta["minimum_order"]
        seller_name=response.meta["seller_name"]



        raw_product_name = response.xpath("//h1[@class='ma-title']/text()").extract()
        product_name = ''.join(raw_product_name).strip(
        ).replace(',','|') if raw_product_name else None

        raw_product_image = response.xpath("//li[@class='item']/div/a/img/@src").extract()
        product_image = "https:" + raw_product_image[0].replace(',','|') if raw_product_image else None

        if product_image == None:
            raw_product_image = response.xpath("//li[@data-role='item']/div/a/img/@src").extract()
            product_image = "https:" + raw_product_image[0].replace(',','|') if raw_product_image else None


        raw_model_number = response.xpath("//span[contains(@title,'Model Number')]/parent::dt/following::dd[1]/div/text()").extract()
        product_model_number = ''.join(raw_model_number).strip(
        ).replace(',','|') if raw_model_number else None

        raw_brand_name = response.xpath(
            "//span[contains(@title,'Brand Name')]/parent::dt/following::dd[1]/div/text()").extract()
        product_brand_name = ''.join(raw_brand_name).strip(
        ).replace(',','|') if raw_brand_name else None

        raw_color = response.xpath(
            "//span[contains(@title,'Color')]/parent::dt/following::dd[1]/div/text()").extract()
        product_color = ''.join(raw_color).strip(
        ).replace(',','|') if raw_color else None

        # raw_certification = response.xpath(
        #     "//td[contains(text(),'Certifications')]/following::td[1]//a[@class='content-value']/text()").extract()
        # product_certification = ''.join(raw_certification).strip(
        # ) if raw_certification else None

        raw_business_type = response.xpath(
            "//div[@class='business-type-lite']/text()").extract()
        company_business_type = ''.join(raw_business_type).strip(
        ).replace(',','|') if raw_business_type else None

        if '"title":"Business Type","value":"' in strhtml and company_business_type == None:
            company_business_type = strhtml.split('"title":"Business Type","value":"',1)[1]
            company_business_type = company_business_type.split('"',1)[0]
            company_business_type = company_business_type.replace(',','|').strip()
        # raw_year_established = response.xpath(
        #     "//td[contains(text(),'Year Established')]/following::td[1]//div[@class='content-value']/text()").extract()
        # company_year_established = ''.join(raw_year_established).strip(
        # ).replace(',','|') if raw_year_established else None

        raw_rating = response.xpath(
            "//a[@class='score-lite']/b/text()").extract()
        product_rating = ''.join(raw_rating).strip(
        ).replace(',', '|') if raw_rating else None

        if '"ratingValue":"' in strhtml and product_rating == None:
            product_rating = strhtml.split('"ratingValue":"',1)[1]
            product_rating = product_rating.split('"',1)[0]
            product_rating = product_rating.replace(',','|').strip()

        raw_reviews = response.xpath(
            "//a[@class='reviews']/text()").extract()
        product_reviews = ''.join(raw_reviews).strip(
        ).replace(',', '|') if raw_reviews else None

        raw_company_name = response.xpath(
            "//a[@class='company-name company-name-lite']/@title").extract()
        company_name = ''.join(raw_company_name).strip(
        ).replace(',', '|') if raw_company_name else None






        try:
            abc = ''
            excel_write = False

            while excel_write == False:

                try:
                    self.ws.cell(row=self.i, column=1).value = str(self.i - 1)
                    self.ws.cell(row=self.i, column=2).value = str(search_keyword).replace("None","")
                    self.ws.cell(row=self.i, column=3).value = response.url
                    self.ws.cell(row=self.i, column=4).value = str(product_name).replace("None","")
                    self.ws.cell(row=self.i, column=5).value = str(product_image).replace("None","")
                    self.ws.cell(row=self.i, column=6).value = str(product_price).replace("None","")
                    self.ws.cell(row=self.i, column=7).value = str(company_name).replace("None","")
                    self.ws.cell(row=self.i, column=8).value = str(product_rating).replace("None","")
                    self.ws.cell(row=self.i, column=9).value = str(product_reviews).replace("None","")
                    self.ws.cell(row=self.i, column=10).value = str(minimum_order).replace("None","")
                    self.ws.cell(row=self.i, column=11).value = str(seller_name).replace("None","")

                    try:
                        column_count = self.ws.max_column
                        rows = self.ws.iter_rows(min_row=1, max_row=1)  # returns a generator of rows
                        first_row = next(rows)  # get the first row
                        headings = [c.value for c in first_row]

                        All_fileds = response.xpath("//div[contains(text(),'Quick Details')]/following::div[1]/dl")

                        for field in All_fileds:
                            label = field.xpath(".//span[@class='attr-name J-attr-name']/@title").extract_first()
                            label = str(label).replace(":","").replace("|","").replace(",","").replace(" ","").strip().lower()
                            value_1 = field.xpath(".//div[@class='ellipsis']/@title").extract_first()
                            if label in headings:
                                self.ws.cell(row=self.i, column=headings.index(label)).value = value_1
                            else:
                                self.ws.cell(row=1, column=column_count).value = label
                                self.ws.cell(row=self.i, column=column_count).value = value_1
                                column_count = column_count + 1

                    except Exception as e:
                        print(e)

                    self.i = self.i + 1
                    self.wb.save('alibaba.xlsx')
                    print("DATA_INSERTED... " + str(self.i))
                    self.wb.close()
                    excel_write = True

                except Exception as e:
                    excel_write = False

        except Exception as e:
            pq = ''



        # writer.writerow(str(search_keyword)+response.url+','+str(product_name)+','+str(product_image)
        #                 +','+str(product_price)+','+str(company_name)+','+str(product_rating)
        #                 +','+str(product_reviews)+','+str(minimum_order)+','+str(seller_name))


    # def close(spider, reason):
    #     spider.output.close()


process = CrawlerProcess({'LOG_ENABLED': False,
                          'CONCURRENT_REQUESTS': 200})
process.crawl(AlibabaCrawlerSpider)
try:
    process.start()
except:
    pass